import { getToken, fetchStocks } from '../services/api';


global.fetch = jest.fn();

describe('API Service Layer Unit Tests', () => {
  beforeEach(() => {
    fetch.mockClear();
  });

  test('getToken successfully retrieves and returns an access token', async () => {
    fetch.mockResolvedValueOnce({
      ok: true,
      json: async () => ({ access_token: 'mock_token_abc', expires_in: 3600 }),
    });

    const token = await getToken();
    expect(token).toBe('mock_token_abc');
    expect(fetch).toHaveBeenCalledTimes(1);
  });

  test('fetchStocks handles 401 unauthorized error by refreshing token and retrying', async () => {
    
    fetch.mockResolvedValueOnce({
      ok: true,
      json: async () => ({ access_token: 'expired_token', expires_in: 3600 }),
    });

    
    fetch.mockResolvedValueOnce({
      status: 401,
      ok: false,
    });

    
    fetch.mockResolvedValueOnce({
      ok: true,
      json: async () => ({ access_token: 'new_fresh_token', expires_in: 3600 }),
    });

   
    fetch.mockResolvedValueOnce({
      ok: true,
      json: async () => [{ symbol: 'RELIANCE', price: 2950, change: 1.0 }],
    });

    const stocks = await fetchStocks();
    expect(stocks).toEqual([{ symbol: 'RELIANCE', price: 2950, change: 1.0 }]);
    // Verifies that retry mechanism was triggered successfully
    expect(fetch).toHaveBeenCalledTimes(4);
  });
});