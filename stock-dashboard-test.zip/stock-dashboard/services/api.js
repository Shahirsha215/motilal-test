const API_BASE_URL = process.env.NEXT_PUBLIC_API_BASE_URL;

let inMemoryToken = null;

export async function getToken() {
  if (inMemoryToken) return inMemoryToken;

  try {
    const response = await fetch(`${API_BASE_URL}/api/auth/token`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        username: 'candidate',
        password: 'Test@123'
      }),
    });

    if (!response.ok) throw new Error('Failed to fetch authentication token');

    const data = await response.json();
    inMemoryToken = data.access_token;
    return inMemoryToken;
  } catch (error) {
    console.error('Token generation error:', error);
    throw error;
  }
}

export async function fetchStocks(isRetry = false) {
  const token = await getToken();

  try {
    const response = await fetch(`${API_BASE_URL}/api/stocks`, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${token}`
      }
    });

    if (response.status === 401 && !isRetry) {
      console.warn('Token expired (401). Refreshing token and retrying...');
      inMemoryToken = null; 
      return await fetchStocks(true); 
    }

    if (!response.ok) {
      throw new Error(`Error fetching stocks: ${response.statusText}`);
    }

    return await response.json();
  } catch (error) {
    console.error('Stock fetch error:', error);
    throw error;
  }
}