This is a [Next.js](https://nextjs.org) project bootstrapped with [`create-next-app`](https://nextjs.org/docs/app/api-reference/cli/create-next-app).

## Getting Started

First, run the development server:

```bash
npm run dev
# or
yarn dev
# or
pnpm dev
# or
bun dev
```

Open [http://localhost:3000](http://localhost:3000) with your browser to see the result.

You can start editing the page by modifying `app/page.tsx`. The page auto-updates as you edit the file.

This project uses [`next/font`](https://nextjs.org/docs/app/building-your-application/optimizing/fonts) to automatically optimize and load [Geist](https://vercel.com/font), a new font family for Vercel.

## Learn More

To learn more about Next.js, take a look at the following resources:

- [Next.js Documentation](https://nextjs.org/docs) - learn about Next.js features and API.
- [Learn Next.js](https://nextjs.org/learn) - an interactive Next.js tutorial.

You can check out [the Next.js GitHub repository](https://github.com/vercel/next.js) - your feedback and contributions are welcome!

## Deploy on Vercel

The easiest way to deploy your Next.js app is to use the [Vercel Platform](https://vercel.com/new?utm_medium=default-template&filter=next.js&utm_source=create-next-app&utm_campaign=create-next-app-readme) from the creators of Next.js.

Check out our [Next.js deployment documentation](https://nextjs.org/docs/app/building-your-application/deploying) for more details.

# Stock Dashboard Application (Motilal Oswal Assessment)

A high-performance, responsive Next.js application built to display real-time stock data retrieved from protected backend APIs with automated token management, search filtering, and price sorting.

##  Features & Requirements Met

- **Secure Authentication Flow**: Automatically requests an access token on load and passes it securely via Bearer headers[cite: 1].
- **Automatic Token Expiry Handling (401 Retry)**: Intercepts `401 Unauthorized` responses, refreshes the access token automatically, and retries the original stock data request[cite: 1].
- **Responsive Stock Table**: Displays stock symbols, current prices, and color-coded percentage changes (green for positive, red for negative)[cite: 1].
- **Interactive Controls**: 
  - Manual **Refresh Button** to reload stock data[cite: 1].
  - Real-time **Symbol Search Bar** (Bonus Task 1)[cite: 1].
  - Price **Sorting** (Low to High / High to Low) (Bonus Task 2)[cite: 1].
  - Live **Stock Counter** badge showing total items (Bonus Task 3)[cite: 1].
- **Environment Configuration**: Utilizes environment variables for API base endpoints (Bonus Task 5)[cite: 1].

---

##  Project Architecture

```text
stock-dashboard/
├── app/
│   ├── api/
│   │   ├── auth/token/route.js   # Mock Token Endpoint (/api/auth/token)
│   │   └── stocks/route.js       # Mock Stock Endpoint (/api/stocks)
│   ├── favicon.ico
│   ├── globals.css               # Tailwind CSS imports
│   ├── layout.tsx                # Root layout wrapper
│   └── page.tsx                  # Main Stock Dashboard UI Component
├── services/
│   └── api.js                    # API service layer handling token fetch, storage, & 401 retries
├── .env.local                    # Environment variables
├── package.json
└── README.md