import { NextResponse } from 'next/server';

export async function POST(request) {
  const body = await request.json();

  // Check dummy credentials from the assessment
  if (body.username === 'candidate' && body.password === 'Test@123') {
    return NextResponse.json({
      access_token: 'sample_token_123_xyz',
      expires_in: 3600
    });
  }

  return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
}