import { NextResponse } from 'next/server';

export async function GET(request) {
  // Check if the request has the Bearer token in headers
  const authHeader = request.headers.get('authorization');

  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  // Return the mock stock list
  return NextResponse.json([
    { symbol: "RELIANCE", price: 2950.25, change: 1.45 },
    { symbol: "TCS", price: 4150.50, change: -0.85 },
    { symbol: "INFY", price: 1875.30, change: 2.15 }
  ]);
}