'use client';

import { useState, useEffect } from 'react';
import { fetchStocks } from '../services/api';

interface Stock {
  symbol: string;
  price: number;
  change: number;
}

export default function StockDashboard() {
  const [stocks, setStocks] = useState<Stock[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [sortOrder, setSortOrder] = useState<string>('none'); 

  const loadStocks = async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await fetchStocks();
      setStocks(data);
    } catch (err) {
      setError('Failed to load stock data. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadStocks();
  }, []);

  const filteredStocks = stocks.filter((stock) =>
    stock.symbol.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const sortedStocks = [...filteredStocks].sort((a, b) => {
    if (sortOrder === 'asc') return a.price - b.price;
    if (sortOrder === 'desc') return b.price - a.price;
    return 0;
  });

  return (
    <main className="min-h-screen bg-gray-50 p-6 md:p-12">
      <div className="max-w-4xl mx-auto bg-white rounded-xl shadow-md overflow-hidden p-6">
        
        {/* Header & Refresh Button */}
        <div className="flex flex-col md:flex-row justify-between items-center mb-6 gap-4">
          <div>
            <h1 className="text-2xl font-bold text-gray-800">Motilal Oswal Stock Dashboard</h1>
            <p className="text-sm text-gray-500">
              Total Stocks Available: <span className="font-semibold text-gray-700">{stocks.length}</span>
            </p>
          </div>
          <button
            onClick={loadStocks}
            className="px-4 py-2 bg-blue-600 text-white text-sm font-medium rounded-lg hover:bg-blue-700 transition"
          >
            Refresh Data 🔄
          </button>
        </div>

        {/* Search and Sorting Controls (Bonus) */}
        <div className="flex flex-col sm:flex-row gap-4 mb-6">
          <input
            type="text"
            placeholder="Search by symbol (e.g. RELIANCE)..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm text-gray-900 placeholder:text-gray-400 bg-white"
          />
          <select
            value={sortOrder}
            onChange={(e) => setSortOrder(e.target.value)}
            className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm text-gray-900 bg-white"
          >
            <option value="none">Sort by Price: Default</option>
            <option value="asc">Price: Low to High</option>
            <option value="desc">Price: High to Low</option>
          </select>
        </div>

        {/* Loading State */}
        {loading && (
          <div className="text-center py-12 text-gray-500 animate-pulse">
            Loading secure stock data...
          </div>
        )}

        {/* Error State */}
        {error && (
          <div className="bg-red-50 text-red-600 p-4 rounded-lg mb-6 text-center text-sm font-medium">
            {error}
          </div>
        )}

        {/* Responsive Table (Steps 5 & 6) */}
        {!loading && !error && (
          <div className="overflow-x-auto border border-gray-200 rounded-lg">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-gray-100 text-gray-700 uppercase text-xs tracking-wider">
                  <th className="py-3 px-4">Stock Symbol</th>
                  <th className="py-3 px-4">Current Price (₹)</th>
                  <th className="py-3 px-4">Change (%)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200 text-sm">
                {sortedStocks.length > 0 ? (
                  sortedStocks.map((stock) => (
                    <tr key={stock.symbol} className="hover:bg-gray-50 transition">
                      <td className="py-3 px-4 font-bold text-gray-800">{stock.symbol}</td>
                      <td className="py-3 px-4 text-gray-600">₹{stock.price.toFixed(2)}</td>
                      <td className={`py-3 px-4 font-semibold ${stock.change >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                        {stock.change >= 0 ? `+${stock.change}%` : `${stock.change}%`}
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={3} className="py-6 text-center text-gray-">
                      No stocks found matching your search.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        )}

      </div>
    </main>
  );
}